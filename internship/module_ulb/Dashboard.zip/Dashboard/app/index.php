<?php include '../../../src/php/dbh.php';
$state = "";?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/css/mdb.min.css" rel="stylesheet">
    <link href="./style.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>


    <title>Ministry of Home Affairs</title>
</head>

<body>
    <section>
        <img src="./images/logo-slider.jpg" class="img img-fluid w-100" />
    </section>


    <section class="m-4">



        <span class="float-right">
            <a class="h2 mr-2" href="#!">
                <i class="fas fa-print"></i>
            </a>
            <a class="h2" href="#!">
                <i class="fas fa-file-pdf"></i>
            </a>
            <a class="h2 ml-2 text-success" href="#!">
                <i class="fas fa-file-excel"></i>
            </a>
            <a class="h4 ml-2 text-secondary" href="../">
                SignOut <i class="fas fa-sign-out-alt"></i>
            </a>
        </span>




        <p class="h1 font-weight-bold text-center">
            <span class="display-4" style="margin-left: 12%;">TULIP STATS</span>
            <br>
            ALL INDIA INTERNSHIPS
        </p>


    </section>
    <hr>

    <section class="m-4">
        <div class="row mt-4">
            <div class="col">
                <label class="h4">
                    <center>
                        STATE WISE ITERNSHIPS
                    </center>
                </label>
                <select id="allIndiaStateWiseSelect" class="select-css">
                    <?php 
                        $sql = "SELECT Distinct ulb_state From ubl_register";
                        $res = mysqli_query($conn,$sql);   
                        while($row = mysqli_fetch_assoc($res)){
                        echo '<option value="'.$row['ulb_state'].'">'.$row['ulb_state'].'</option>';
                        }
                    ?>
                </select>
                
                <form id="allIndiaStateWiseForm" method="POST">
                    <input id="stateNameField" name="stateNameField" type="hidden" value="" />
                </form>
                
                <script>
                    $(document).ready(function(){
                        $("#allIndiaStateWiseSelect").change(function(){
                            var selected = $(this).children("option:selected").val();
                            $("#stateNameField").val(selected);
                            $("#allIndiaStateWiseForm").submit();
                        });
                    });
                </script>
            </div>

            <div class="col">
                <p class="display-4 font-weight-bold text-center">
                    <img src="https://img.icons8.com/color/200/000000/india.png" />
                    <br>
                    PAN INDIA DATA
                </p>
            </div>

            <div class="col">
                <label class="h4">
                    <center>
                        ULB WISE INTERNSHIPS
                    </center>
                </label>
                <select id="allIndiaUlbWiseSelect" class="select-css">
                    <?php 
                $sql = "SELECT Distinct ulb_organisaton From ubl_register";
                 $res = mysqli_query($conn,$sql);   
                 while($row = mysqli_fetch_assoc($res)){
                   echo '<option value="'.$row['ulb_organisaton'].'">'.$row['ulb_organisaton'].'</option>';
                 }
                    ?>
                </select>

                <form id="allIndiaUlbWiseForm" method="POST">
                    <input id="UlbNameField" name="UlbNameField" type="hidden" value="" />
                </form>
                
                <script>
                    $(document).ready(function(){
                        $("#allIndiaUlbWiseSelect").change(function(){
                            var selected = $(this).children("option:selected").val();
                            $("#UlbNameField").val(selected);
                            $("#allIndiaUlbWiseForm").submit();
                        });
                    });
                </script>
            </div>

        </div>
      


        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                            <h5>
                                    TOTAL INTERNSHIPS
                                </h5>
                            <?php
                $sql = "SELECT count(*) as total From post_internship_government";
                $res = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_assoc($res))
                {                       
                       echo $row['total'];
                }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    INTERNSHIPS IN PROGRESS
                                </h5>
                                <?php
                $sql = "SELECT count(*) as total From government_internship_apply where status = 2";
                $res = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_assoc($res))
                {                       
                       echo $row['total'];
                }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    INTERNSHIPS COMPLETED
                                </h5>
                                </h5>
                                <?php
                $sql = "SELECT count(*) as total From government_internship_apply where status = 3";
                $res = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_assoc($res))
                {                       
                       echo $row['total'];
                }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
        </div>


        <div class="row mt-4">
            <div class="col-4">
                <!-- India Map -->
                <?php include './map.php' ?>
                <!-- India Map -->
            </div>

            <div class="col">
                <div class="table-wrapper-scroll-y my-custom-scrollbar">
                    <table class="table h1 table-bordered table-striped mb-0">
                        <thead>
                        
                            <tr>
                                <th class="h5" scope="col">State</th>
                                <th class="h5" scope="col">Total Internships</th>
                                <th class="h5" scope="col">Completed</th>
                                <th class="h5" scope="col">Progress</th>
                            </tr>
                            
                        </thead>
                        <tbody>
                        <?php
                        $sql = "SELECT distinct u.ulb_state, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = u.ulb_state) as total, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = u.ulb_state and a.status = 0)as ongoing, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = u.ulb_state and a.status = 3) as completed from ubl_register u inner join post_internship_government g on g.company_id = u.ulb_company_id";
                        $res = mysqli_query($conn,$sql);
                        while($row = mysqli_fetch_assoc($res)){
                            echo '<tr>
                                <th class="h5" scope="row">'.$row['ulb_state'].'</th>
                                <td class="h5">'.$row['total'].'</td>
                                <td class="h5">'.$row['completed'].'</td>
                                <td class="h5">'.$row['ongoing'].'</td>
                            </tr>';
                        }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>


        </div>
        <?php 
            if (isset($_POST['stateNameField'])) {
                $state = mysqli_real_escape_string($conn, $_POST['stateNameField']);
           
            ?>
        <hr>

        <p class="display-4 font-weight-bold text-center">
            <img src="https://img.icons8.com/color/80/000000/taj-mahal.png" />
            <br>
           <?php echo $state; ?> STATE DATA
        </p>

       

        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    TOTAL INTERNSHIPS
                                </h5>
                                </h5>
                                <?php
                                    $sql = "SELECT count(*) as total From post_internship_government where state = '$state'";
                                    $res = mysqli_query($conn,$sql);
                                    while($row = mysqli_fetch_assoc($res))
                                    {                       
                                        echo $row['total'];
                                    }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    INTERNSHIPS IN PROGRESS
                                </h5>
                                </h5>
                                <?php
                $sql = "SELECT count(*) as total From government_internship_apply a inner join post_internship_government g on g.uid = a.internship_uid where g.state = '$state'  ";
                $res = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_assoc($res))
                {                       
                       echo $row['total'];
                }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    INTERNSHIPS COMPLETED
                                </h5>
                                </h5>
                                <?php
                $sql = "SELECT count(*) as total From government_internship_apply where status = 2";
                $res = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_assoc($res))
                {                       
                       echo $row['total'];
                }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
        </div>
            <?php }else{?>
                <p class="display-4 font-weight-bold text-center">
            <img src="https://img.icons8.com/color/80/000000/taj-mahal.png" />
            <br>
           <?php echo "Uttar Pradesh"; ?>STATE DATA
        </p>

       

        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    TOTAL INTERNSHIPS
                                </h5>
                                </h5>
                                <?php
                                    $sql = "SELECT count(*) as total From post_internship_government where state = 'Uttar Pradesh'";
                                    $res = mysqli_query($conn,$sql);
                                    while($row = mysqli_fetch_assoc($res))
                                    {                       
                                        echo $row['total'];
                                    }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    INTERNSHIPS IN PROGRESS
                                </h5>
                                </h5>
                                <?php
                $sql = "SELECT count(*) as total From government_internship_apply a inner join post_internship_government g on g.uid = a.internship_uid where g.state = 'Uttar Pradesh'  ";
                $res = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_assoc($res))
                {                       
                       echo $row['total'];
                }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    INTERNSHIPS COMPLETED
                                </h5>
                                </h5>
                                <?php
                $sql = "SELECT count(*) as total From government_internship_apply a inner join post_internship_government g on g.uid = a.internship_uid where g.state = 'Uttar Pradesh' and a.status = 3";
                $res = mysqli_query($conn,$sql);
                while($row = mysqli_fetch_assoc($res))
                {                       
                       echo $row['total'];
                }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
        </div>
            <?php }?>
        <div class="row mt-4">
            <div class="col-4">
                <!-- India Map -->
                <img class="w-50"
                    src="https://upload.wikimedia.org/wikipedia/commons/c/c9/Delhi_Municipalities_Cantt.svg" />
                <!-- India Map -->
            </div>

            



            <div class="col">
                <label class="h4">
                    <center>
                        CITY WISE DATA
                    </center>
                </label>
                <div class="table-wrapper-scroll-y my-custom-scrollbar">
                    <table class="table table-bordered table-striped mb-0">
                        <thead>
                            <tr>
                                <th class="h5" scope="col">City</th>
                                <th class="h5" scope="col">Total Internships</th>
                                <th class="h5" scope="col">Completed</th>
                                <th class="h5" scope="col">Progress</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $sql = "SELECT distinct u.ulb_city, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and g.locations = u.ulb_city) as total, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and a.status = 0 and g.locations = u.ulb_city)as ongoing, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and a.status = 3 and g.locations = u.ulb_city) as completed from ubl_register u inner join post_internship_government g on g.company_id = u.ulb_company_id";
                        $res = mysqli_query($conn,$sql);
                        while($row = mysqli_fetch_assoc($res)){
                            echo '<tr>
                                <th class="h5" scope="row">'.$row['ulb_city'].'</th>
                                <td class="h5">'.$row['total'].'</td>
                                <td class="h5">'.$row['completed'].'</td>
                                <td class="h5">'.$row['ongoing'].'</td>
                            </tr>';
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>


        </div>

        <div class="row mt-2">
            <div class="col">
                <label class="h4">
                    <center>
                        ULB WISE DATA
                    </center>
                </label>
                <div class="table-wrapper-scroll-y my-custom-scrollbar">
                    <table class="table table-bordered table-striped mb-0">
                        <thead>
                            <tr>
                                <th class="h5" scope="col">ULB</th>
                                <th class="h5" scope="col">Total Internships</th>
                                <th class="h5" scope="col">Completed</th>
                                <th class="h5" scope="col">Progress</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $sql = "SELECT distinct u.ulb_organisaton, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and g.locations = u.ulb_city) as total, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and a.status = 0 and g.locations = u.ulb_city)as ongoing, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and a.status = 3 and g.locations = u.ulb_city) as completed from ubl_register u inner join post_internship_government g on g.company_id = u.ulb_company_id";
                        $res = mysqli_query($conn,$sql);
                        while($row = mysqli_fetch_assoc($res)){
                            echo '<tr>
                                <th class="h5" scope="row">'.$row['ulb_organisaton'].'</th>
                                <td class="h5">'.$row['total'].'</td>
                                <td class="h5">'.$row['completed'].'</td>
                                <td class="h5">'.$row['ongoing'].'</td>
                            </tr>';
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="col">
                <label class="h4">
                    <center>
                        DEPARTMENT WISE
                    </center>
                </label>
                <div class="table-wrapper-scroll-y my-custom-scrollbar">
                    <table class="table table-bordered table-striped mb-0">
                        <thead>
                            <tr>
                                <th class="h5" scope="col">Department</th>
                                <th class="h5" scope="col">Total Internships</th>
                                <th class="h5" scope="col">Completed</th>
                                <th class="h5" scope="col">Progress</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $sql = "SELECT distinct g.department, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and g.locations = u.ulb_city) as total, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and a.status = 0 and g.locations = u.ulb_city)as ongoing, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and a.status = 3 and g.locations = u.ulb_city) as completed from ubl_register u inner join post_internship_government g on g.company_id = u.ulb_company_id";
                        $res = mysqli_query($conn,$sql);
                        while($row = mysqli_fetch_assoc($res)){
                            echo '<tr>
                                <th class="h5" scope="row">'.$row['department'].'</th>
                                <td class="h5">'.$row['total'].'</td>
                                <td class="h5">'.$row['completed'].'</td>
                                <td class="h5">'.$row['ongoing'].'</td>
                            </tr>';
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>


        </div>


        <hr>
        <?php 
            if (isset($_POST['UlbNameField'])) {
                $ulb = mysqli_real_escape_string($conn, $_POST['UlbNameField']);
                // echo $ulb;
            
        ?>

        <p class="display-4 font-weight-bold text-center">
            <img src="https://img.icons8.com/color/100/000000/move-shit-around.png" />
            <br>
            <?php echo $ulb ?>  DATA
        </p>


        <div class="row mt-4">
            <div class="col">
                <!-- India Map -->
                <center>
                    <img class="w-25" src="https://nulm.gov.in/images/MoHUALogo.png" />
                </center>
                <!-- India Map -->
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                            <h5>TOTAL INTERNSHIP</h5>
                            <?php
                                    $sql = "SELECT count(*) as total From post_internship_government g inner join ubl_register u on g.company_id = u.ulb_company_id where ulb_organisaton = '$ulb'";
                                    $res = mysqli_query($conn,$sql);
                                    while($row = mysqli_fetch_assoc($res))
                                    {                       
                                        echo $row['total'];
                                    }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                            <h5>INTERNSHIP IN PROGRESS</h5>
                            <?php
                                      $sql = "SELECT count(*) as total From government_internship_apply a inner join post_internship_government g on g.uid = a.internship_uid inner join ubl_register u on a.company_id = u.ulb_company_id where u.ulb_organisaton = '$ulb' and a.status = 1 or a.status = 2";
                                      $res = mysqli_query($conn,$sql);
                                      while($row = mysqli_fetch_assoc($res))
                                      {                       
                                             echo $row['total'];
                                      }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    INTERNSHIPS COMPLETED
                                </h5>
                                <?php
                                      $sql = "SELECT count(*) as total From government_internship_apply a inner join post_internship_government g on g.uid = a.internship_uid inner join ubl_register u on a.company_id = u.ulb_company_id where u.ulb_organisaton = '$ulb' and a.status = 3";
                                      $res = mysqli_query($conn,$sql);
                                      while($row = mysqli_fetch_assoc($res))
                                      {                       
                                             echo $row['total'];
                                      }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    INTERNSHIPS COMPLETED
                                </h5>
                                1,562
                            </center>
                        </span>
                    </div>
                </div>
            </div>
        </div>
            <?php }else{
                ?>
                 <div class="row mt-4">
            <div class="col">
                <!-- India Map -->
                <center>
                    <img class="w-25" src="https://nulm.gov.in/images/MoHUALogo.png" />
                </center>
                <!-- India Map -->
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                            <h5>TOTAL INTERNSHIP</h5>
                            <?php
                                    $sql = "SELECT count(*) as total From post_internship_government g inner join ubl_register u on g.company_id = u.ulb_company_id where ulb_organisaton = 'Municipal Corporation Lucknow'";
                                    $res = mysqli_query($conn,$sql);
                                    while($row = mysqli_fetch_assoc($res))
                                    {                       
                                        echo $row['total'];
                                    }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                            <h5>INTERNSHIP IN PROGRESS</h5>
                            <?php
                                      $sql = "SELECT count(*) as total From government_internship_apply a inner join post_internship_government g on g.uid = a.internship_uid inner join ubl_register u on a.company_id = u.ulb_company_id where u.ulb_organisaton = 'Municipal Corporation Lucknow' and a.status = 1 or a.status = 2 ";
                                      $res = mysqli_query($conn,$sql);
                                      while($row = mysqli_fetch_assoc($res))
                                      {                       
                                             echo $row['total'];
                                      }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    INTERNSHIPS COMPLETED
                                </h5>
                                <?php
                                      $sql = "SELECT count(*) as total From government_internship_apply a inner join post_internship_government g on g.uid = a.internship_uid inner join ubl_register u on a.company_id = u.ulb_company_id where u.ulb_organisaton = 'Municipal Corporation Lucknow' and a.status = 1 or a.status = 3";
                                      $res = mysqli_query($conn,$sql);
                                      while($row = mysqli_fetch_assoc($res))
                                      {                       
                                             echo $row['total'];
                                      }
                                ?>
                            </center>
                        </span>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <span class="display-3 font-weight-bold color-dashboard">
                            <center>
                                <h5>
                                    GENDER 
                                 MALE FEMALE
                                </h5>
                                1,562
                            </center>
                        </span>
                    </div>
                </div>
            </div>
        </div>           
       <?php     
            }          
            ?>

        <div class="row mt-4">
            <div class="col">
                <label class="h4">
                    <center>
                        DEPARTMENT WISE DATA
                    </center>
                </label>
                <div class="table-wrapper-scroll-y my-custom-scrollbar">
                    <table class="table table-bordered table-striped mb-0">
                        <thead>
                            <tr>
                                <th class="h5" scope="col">Department</th>
                                <th class="h5" scope="col">Total Internships</th>
                                <th class="h5" scope="col">Completed</th>
                                <th class="h5" scope="col">Progress</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $sql = "SELECT distinct g.department, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where u.ulb_organisaton = '$ulb' and g.locations = u.ulb_city) as total, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and a.status = 0 and g.locations = u.ulb_city)as ongoing, (select count(*) from government_internship_apply a inner join post_internship_government g on a.internship_uid = g.uid where g.state = '$state' and a.status = 3 and g.locations = u.ulb_city) as completed from ubl_register u inner join post_internship_government g on g.company_id = u.ulb_company_id";
                        $res = mysqli_query($conn,$sql);
                        while($row = mysqli_fetch_assoc($res)){
                            echo '<tr>
                                <th class="h5" scope="row">'.$row['department'].'</th>
                                <td class="h5">'.$row['total'].'</td>
                                <td class="h5">'.$row['completed'].'</td>
                                <td class="h5">'.$row['ongoing'].'</td>
                            </tr>';
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </section>




    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js">
    </script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.16.0/js/mdb.min.js">
    </script>
</body>

</html>